public class Main {
    public static void main(String[] args) {
        MaxSkewHeap heap = new MaxSkewHeap();

        // Test insert
        heap.insert(10);
        heap.insert(20);
        heap.insert(30);
        heap.insert(40);
        heap.insert(50);

        // Test search
        System.out.println("Search 30: " + heap.search(30));
        System.out.println("Search 60: " + heap.search(60));

        // Test searchPath
        System.out.println("Search path for 30: " + heap.searchPath(30));
        System.out.println("Search path for 60: " + heap.searchPath(60));

        // Test isLeftist and isRightist
        System.out.println("Is leftist: " + heap.isLeftist());
        System.out.println("Is rightist: " + heap.isRightist());

        // Test remove
        heap.remove(30);
        System.out.println("Search path for 30 after removal: " + heap.searchPath(30));

        // Test toString and toStringOneLine
        System.out.println("Heap (multi-line):\n" + heap.toString());
        System.out.println("Heap (one line): " + heap.toStringOneLine());
    }
}
