public class RedBlackTree<T extends Comparable<T>> {

    /*
     * Sentinel is not the root. Go check the text book if this doesn't make sense
     */
    public RedBlackNode<T> SENTINEL;
    public RedBlackNode<T> NULL_NODE;
    private RedBlackNode<T> root;

    public static final int RED = 1;
    public static final int BLACK = 0;

    public RedBlackTree() {
        // Initialize sentinel and null nodes
        SENTINEL = new RedBlackNode<>(null);
        SENTINEL.colour = BLACK; // Sentinel is always black
        NULL_NODE = new RedBlackNode<>(null);
        NULL_NODE.colour = BLACK; // Null node is also black
        root = NULL_NODE; // Initialize root as null node
        SENTINEL.right = NULL_NODE;

    }

    public RedBlackNode<T> getRoot() {
        return root;
    }

    public void bottomUpInsert(T data) {
        if (data == NULL_NODE) {
            throw new IllegalArgumentException("Data cannot be null");
        }

        RedBlackNode<T> newNode = new RedBlackNode<>(data);
        newNode.left = NULL_NODE;
        newNode.right = NULL_NODE;
        newNode.colour = RED;

        // If the tree is empty, set the new node as the root
        if (SENTINEL.right == NULL_NODE) {
            SENTINEL.right = newNode;
            newNode.parent = SENTINEL;
        } else {
            // Perform a standard binary search tree insertion

            RedBlackNode<T> current = SENTINEL.right;
            while (current != NULL_NODE) {

                // Ensure current.data is not null before comparing
                int compareResult = data.compareTo(current.data);
                if (compareResult < 0) {
                    if (current.left == NULL_NODE) {
                        current.left = newNode;
                        newNode.parent = current;
                        break;
                    }
                    current = current.left;
                } else if (compareResult > 0) {
                    if (current.right == NULL_NODE) {
                        current.right = newNode;
                        newNode.parent = current;
                        break;
                    }
                    current = current.right;
                } else {
                    // Node with the same data already exists; do nothing
                    return;
                }
            }
        }

        // Fix any violations introduced by the insertion
        fixInsertionViolations(newNode);
    }

    private void fixInsertionViolations(RedBlackNode<T> node) {
        while (node != getRoot() && node.parent != null && node.parent != SENTINEL && node.parent.colour == RED) {
            if (node.parent.parent == null) {
                break;
            }
            if (node.parent.parent == SENTINEL) {
                break;
            }
            if (node.parent == node.parent.parent.left) {
                // Uncle node
                RedBlackNode<T> uncle = node.parent.parent.right;
                // Case 1: Uncle is red
                if (uncle != null && uncle != SENTINEL && uncle.colour == RED) {
                    node.parent.colour = BLACK;
                    uncle.colour = BLACK;
                    node.parent.parent.colour = RED;
                    node = node.parent.parent;
                } else { // Case 2: Node is right child
                    if (node == node.parent.right) {
                        node = node.parent;
                        rotateLeft(node);
                    }
                    // Case 3: Node is left child
                    node.parent.parent.colour = RED;
                    node.parent.colour = BLACK;

                    rightRotate(node.parent.parent);
                }
            } else { // Mirror cases: parent is the right child
                RedBlackNode<T> uncle = node.parent.parent.left;

                if (uncle != null && uncle != SENTINEL && uncle.colour == RED) {

                    node.parent.colour = BLACK;
                    uncle.colour = BLACK;
                    node.parent.parent.colour = RED;
                    node = node.parent.parent;
                } else {
                    if (node == node.parent.left) {
                        node = node.parent;
                        rightRotate(node);
                    }
                    node.parent.colour = BLACK;
                    node.parent.parent.colour = RED;
                    rotateLeft(node.parent.parent);
                }
            }
        }
        SENTINEL.right.colour = BLACK;
    }

    private void rotateLeft(RedBlackNode<T> x) {

        RedBlackNode<T> y = x.right;
        // y left subtree becomes x right subtree
        x.right = y.left;

        // Check if y left subtree is not NULLNODE
        if (y.left != NULL_NODE) {

            y.left.parent = x;
        }

        y.parent = x.parent;

        if (x.parent == SENTINEL) {

            SENTINEL.right = y;

        } else if (x == x.parent.left) {

            x.parent.left = y;
        } else {
            x.parent.right = y;
        }

        y.left = x;

        x.parent = y;
    }

    private void leftRotate(RedBlackNode<T> x) {
        RedBlackNode<T> y = x.right;
        x.right = y.left;
        if (y.left != NULL_NODE) {
            y.left.parent = x;
        }
        y.parent = x.parent;
        if (x.parent == NULL_NODE) {
            root = y;
        } else if (x == x.parent.left) {
            x.parent.left = y;
        } else {
            x.parent.right = y;
        }
        y.left = x;
        x.parent = y;
    }

    private void rightRotate(RedBlackNode<T> y) {
        RedBlackNode<T> x = y.left;
        y.left = x.right;
        if (x.right != NULL_NODE) {
            x.right.parent = y;
        }
        x.parent = y.parent;
        if (y.parent == NULL_NODE) {
            root = x;
        } else if (y == y.parent.left) {
            y.parent.left = x;
        } else {
            y.parent.right = x;
        }
        x.right = y;
        y.parent = x;
    }

    public boolean isValidRedBlackTree() {
        return isValidRedBlackTree(root, 0, -1);

    }

    private boolean isValidRedBlackTree(RedBlackNode<T> node, int blackDepth, int expectedBlackDepth) {
        if (node == NULL_NODE) {
            // Base case: Reached a leaf (NIL) node
            return blackDepth == expectedBlackDepth;
        }

        // Property 1: Every node is either red or black
        if (node.colour != RED && node.colour != BLACK) {
            return false;
        }

        // Property 3: If a node is red, then its children are black
        if (node.colour == RED) {
            if (node.left.colour != BLACK || node.right.colour != BLACK) {
                return false;
            }
        }

        // Update black depth
        int newBlackDepth = blackDepth + (node.colour == BLACK ? 1 : 0);

        // Property 4: Every path from a given node to any descendant NULL nodes
        // contains the same number of black nodes
        if (!isValidRedBlackTree(node.left, newBlackDepth, expectedBlackDepth) ||
                !isValidRedBlackTree(node.right, newBlackDepth, expectedBlackDepth)) {
            return false;
        }

        // Property 2: The root of the tree is always black
        if (node == root && node.colour != BLACK) {
            return false;
        }

        // Update expected black depth if necessary
        if (expectedBlackDepth == -1) {
            expectedBlackDepth = newBlackDepth;
        } else if (newBlackDepth != expectedBlackDepth) {
            return false;
        }

        return true;
    }

    public void topDownDelete(T data) {
        // Find the node to be deleted (if it exists)
        RedBlackNode<T> nodeToDelete = searchNode(root, data);
        if (nodeToDelete == NULL_NODE) {
            // Node with the given data does not exist; do nothing
            return;
        }

        // Determine the replacement node (smallest node in the right subtree)
        RedBlackNode<T> replacementNode;
        if (nodeToDelete.right != NULL_NODE) {
            // Node has at most one child
            findSmallestNode(nodeToDelete.right);
        }
        {
            // Node has two children; find the smallest node in the right subtree
            replacementNode = findSmallestNode(nodeToDelete.right);
        }

        // Perform the actual deletion
        deleteNode(nodeToDelete, replacementNode);
    }

    private RedBlackNode<T> searchNode(RedBlackNode<T> node, T data) {
        if (node == NULL_NODE || data.compareTo(node.data) == 0) {
            return node;
        }
        if (data.compareTo(node.data) < 0) {
            return searchNode(node.left, data);
        }
        return searchNode(node.right, data);
    }

    private RedBlackNode<T> findSmallestNode(RedBlackNode<T> node) {
        while (node.left != NULL_NODE) {
            node = node.left;
        }
        return node;
    }

    private void deleteNode(RedBlackNode<T> nodeToDelete, RedBlackNode<T> replacementNode) {
        // Save the original color of the replacement node
        int originalColor = replacementNode.colour;

        // Determine the child of the replacement node (if any)
        RedBlackNode<T> childNode;
        if (replacementNode.left != NULL_NODE) {
            childNode = replacementNode.left;
        } else {
            childNode = replacementNode.right;
        }

        // Replace the nodeToDelete with the replacementNode
        replacementNode.left = nodeToDelete.left;
        replacementNode.right = nodeToDelete.right;
        replacementNode.parent = nodeToDelete.parent;
        replacementNode.colour = nodeToDelete.colour;
        if (nodeToDelete == root) {
            root = replacementNode;
        } else if (nodeToDelete == nodeToDelete.parent.left) {
            nodeToDelete.parent.left = replacementNode;
        } else {
            nodeToDelete.parent.right = replacementNode;
        }
        if (replacementNode.left != NULL_NODE) {
            replacementNode.left.parent = replacementNode;
        }
        if (replacementNode.right != NULL_NODE) {
            replacementNode.right.parent = replacementNode;
        }

        // Fix violations introduced by the deletion
        if (originalColor == BLACK) {
            deleteFix(childNode);
        }
    }

    private void deleteFix(RedBlackNode<T> node) {
        while (node != root && node.colour == BLACK) {
            if (node == node.parent.left) {
                RedBlackNode<T> sibling = node.parent.right;
                if (sibling.colour == RED) {
                    // Case 1: Sibling is red
                    sibling.colour = BLACK;
                    node.parent.colour = RED;
                    leftRotate(node.parent);
                    sibling = node.parent.right;
                }
                if (sibling.left.colour == BLACK && sibling.right.colour == BLACK) {
                    // Case 2: Both children of sibling are black
                    sibling.colour = RED;
                    node = node.parent;
                } else {
                    if (sibling.right.colour == BLACK) {
                        // Case 3: Sibling's right child is black
                        sibling.left.colour = BLACK;
                        sibling.colour = RED;
                        rightRotate(sibling);
                        sibling = node.parent.right;
                    }
                    // Case 4: Sibling's right child is red
                    sibling.colour = node.parent.colour;
                    node.parent.colour = BLACK;
                    sibling.right.colour = BLACK;
                    leftRotate(node.parent);
                    node = root; // Terminate the loop
                }
            } else {
                // Symmetric cases (swap left and right)
                RedBlackNode<T> sibling = node.parent.left;
                if (sibling.colour == RED) {
                    // Case 1: Sibling is red
                    sibling.colour = BLACK;
                    node.parent.colour = RED;
                    rightRotate(node.parent);
                    sibling = node.parent.left;
                }
                if (sibling.left.colour == BLACK && sibling.right.colour == BLACK) {
                    // Case 2: Both children of sibling are black
                    sibling.colour = RED;
                    node = node.parent;
                } else {
                    if (sibling.left.colour == BLACK) {
                        // Case 3: Sibling's left child is black
                        sibling.right.colour = BLACK;
                        sibling.colour = RED;
                        leftRotate(sibling);
                        sibling = node.parent.left;
                    }
                    // Case 4: Sibling's left child is red
                    sibling.colour = node.parent.colour;
                    node.parent.colour = BLACK;
                    sibling.left.colour = BLACK;
                    rightRotate(node.parent);
                    node = root; // Terminate the loop
                }
            }
        }
        node.colour = BLACK; // Ensure the root is black
    }

    /* -------------------------------------------------------------------------- */
    /* Private methods, which shouldn't be called from outside the class */
    /* -------------------------------------------------------------------------- */

    /* -------------------------------------------------------------------------- */
    /* Please don't change this toString, I worked really hard to make it pretty. */
    /* Also, it matches the website. -------------------------------------------- */
    /* Also, also, we might test against it ;) ---------------------------------- */
    /* -------------------------------------------------------------------------- */
    private StringBuilder toString(RedBlackNode<T> node, StringBuilder prefix, boolean isTail, StringBuilder sb) {
        if (node.right != NULL_NODE) {
            toString(node.right, new StringBuilder().append(prefix).append(isTail ? "│   " : "    "), false, sb);
        }
        sb.append(prefix).append(isTail ? "└── " : "┌── ").append(node.toString()).append("\n");
        if (node.left != NULL_NODE) {
            toString(node.left, new StringBuilder().append(prefix).append(isTail ? "    " : "│   "), true, sb);
        }
        return sb;
    }

    @Override
    public String toString() {
        return SENTINEL.right == NULL_NODE ? "Empty tree"
                : toString(SENTINEL.right, new StringBuilder(), true, new StringBuilder()).toString();
    }

    public String toVis() {
        return toVisHelper(getRoot());
    }

    private String toVisHelper(RedBlackNode<T> node) {
        if (node == NULL_NODE) {
            return "{}";
        }
        String leftStr = toVisHelper(node.left);
        String rightStr = toVisHelper(node.right);
        return "{" + node.toString() + leftStr + rightStr + "}";
    }

}
